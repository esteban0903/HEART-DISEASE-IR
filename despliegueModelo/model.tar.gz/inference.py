
import json
import pickle
import numpy as np

def model_fn(model_dir):
    '''Carga modelo desde directorio'''
    with open(f'{model_dir}/heart_disease_model.pkl', 'rb') as f:
        model = pickle.load(f)
    return model

def input_fn(request_body, content_type):
    '''Procesa request JSON'''
    if content_type == 'application/json':
        data = json.loads(request_body)
        # Espera formato: {"Age": 65, "BP": 160, "Cholesterol": 320, ...}
        features = np.array([
            data['Age'], data['BP'], data['Cholesterol'],
            data['Max_HR'], data['ST_depression'], data['Vessels']
        ]).reshape(1, -1)
        return features
    else:
        raise ValueError(f'Content type {content_type} not supported')

def predict_fn(input_data, model):
    '''Hace predicción'''
    # Normalizar
    X_norm = (input_data - model['scaler_mean']) / model['scaler_scale']
    # Predicción
    z = np.dot(X_norm, model['w']) + model['b']
    prob = 1 / (1 + np.exp(-z))
    pred = (prob >= 0.5).astype(int)
    
    return {
        'prediction': int(pred[0]),
        'probability': float(prob[0]),
        'risk_level': 'high risk' if prob[0] >= 0.7 else 'moderate' if prob[0] >= 0.4 else 'low risk'
    }

def output_fn(prediction, accept):
    '''Formatea output'''
    return json.dumps(prediction), 'application/json'
